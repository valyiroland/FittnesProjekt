﻿using FitprojectAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FitprojectAPI.Controllers
{
    /* [Route("[controller]")]
     [ApiController]
     public class IngredientsController : ControllerBase
     {
         [HttpGet] public IActionResult Get()
         {
             using(var context = new FitprojectContext())
             {
                 try
                 {
                     List<FitprojectIngredient> result = context.FitprojectCategories.Include(x=>x.Name).Select(x=>x.)
                     return Ok(result);
                 }
                 catch (Exception ex)
                 {
                     return BadRequest(ex.Message);

                 }
             }*/
}


