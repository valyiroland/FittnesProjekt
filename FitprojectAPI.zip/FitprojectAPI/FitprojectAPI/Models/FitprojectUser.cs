﻿using System;
using System.Collections.Generic;

namespace FitprojectAPI.Models;

public partial class FitprojectUser
{
    public int Id { get; set; }

    public string Name { get; set; } = null!;

    public string Password { get; set; } = null!;

    public string Gender { get; set; } = null!;

    public virtual ICollection<FitprojectBmi> FitprojectBmis { get; set; } = new List<FitprojectBmi>();

    public virtual ICollection<FitprojectCalory> FitprojectCalories { get; set; } = new List<FitprojectCalory>();
}
